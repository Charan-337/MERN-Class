import Timeupdate from './components/Timeupdate';

import React from 'react';

const App = () => {
  return (
    <div>
      <Timeupdate />
    </div>
  );
};

export default App;
