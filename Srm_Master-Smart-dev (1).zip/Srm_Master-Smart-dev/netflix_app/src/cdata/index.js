const cdata = [
    {
        imgSrc: 'https://cdn.wallpapersafari.com/84/6/VH8Qg3.jpg',
        
        title:' A Netflix Original Series',
        sname:'JOKER',
        link:'https://www.netflix.com/in/title/80990668?source=35'
      
    },
    {
        imgSrc:"https://wallpapercave.com/wp/wp2497187.jpg",
        imgSrc:'https://c4.wallpaperflare.com/wallpaper/572/47/710/zipper-ragnarok-lightning-warrior-gladiator-hd-wallpaper-thumb.jpg',
        title:' A Netflix Original Series',
        sname:'THOR',
        link:'https://www.netflix.com/in/title/80990668?source=35',  
    },
    {
        imgSrc:'https://www.wallpapertip.com/wmimgs/84-843938_full-hd-1080p-iron-man.jpg',
        
        title:' A Netflix Original Series',
        sname:'IRON MAN',
        link:'https://www.netflix.com/in/title/80990668?source=35'
    },
    {
        imgSrc:'https://static-koimoi.akamaized.net/wp-content/new-galleries/2018/01/koimoi-audience-poll-vote-favourite-hollywood-movie-2017-9.jpg',
        title:' A Netflix Original Series',
        sname:'JUMANJI',
        link:'https://www.netflix.com/in/title/80990668?source=35'
      
    },
    {
        imgSrc:'https://i.ytimg.com/vi/-QQWSzx3nG8/maxresdefault.jpg',
        title:' A Netflix Original Series',
        sname:'HASEENA',
        link:'https://www.netflix.com/in/title/80990668?source=35'
      
    },
    {
    imgSrc: 'https://wallpapercave.com/wp/3rNLP4q.jpg',
    title:' A Netflix Original Series',
    sname:'FANDA',
    link:'https://www.netflix.com/in/title/80990668?source=35'
  
    }
]

export default cdata;