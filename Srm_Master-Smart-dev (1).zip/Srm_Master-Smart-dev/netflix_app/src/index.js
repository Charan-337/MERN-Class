
import React from 'react'
import reactDom from 'react-dom'
import App from './container/App/App'
import './index.css'


reactDom.render(
  <App/>,document.getElementById("root")
)